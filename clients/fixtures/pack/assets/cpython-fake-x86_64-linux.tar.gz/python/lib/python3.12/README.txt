The fake standard library.
